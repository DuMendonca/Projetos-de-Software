<!DOCTYPE html>
<html lang="pt-br">
<head>
  <title>Pagina Inicial</title>
  <meta charset="UTF-8">
  <link rel="stylesheet" href="../css/paginaAdm.css">
</head>
<body>
    <?php include("menu.php"); ?>
<div>
  <img src="../img/img.png">
</div>
</body>
</html>
