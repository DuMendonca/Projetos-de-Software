<link rel="stylesheet" href="../css/menu.css"/>
<header id="cabecalho">
	<nav id="menu">
		<ul id="menuPrincipal">
			<li><a href="paginaAdminis.php" class="menuPaginas">Pagina Incial</a></li>
			<li><a href="registroForm.php" class="menuPaginas">Registro de Clientes</a></li>
			<li id="logout"><a href="../index.php"><img src="../img/saida.png" id="img1"></a></li>
		</ul>
	</nav>
</header>
