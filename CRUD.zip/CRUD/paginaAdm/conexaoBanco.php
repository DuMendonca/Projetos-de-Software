<?php

$conexao = mysqli_connect("localhost","root","root","bd_clinicaestetica");
$conexao -> set_charset("utf-8");

 ?>
