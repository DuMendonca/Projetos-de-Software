$(document).ready(function () {
      var $campoTel = $("#telefone1");
       $campoTel.mask('(47)0000-0000', {reverse: true});
  });
