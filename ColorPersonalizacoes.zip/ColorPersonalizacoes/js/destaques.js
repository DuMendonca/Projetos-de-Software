$(document).ready(function(){
  $('.carrossel').slick({
	dots: true,
	infinite: true,
	slidesToShow: 1,
	slidesToScroll: 1,
	autoplay: true,
  	autoplaySpeed: 1550
  });
});